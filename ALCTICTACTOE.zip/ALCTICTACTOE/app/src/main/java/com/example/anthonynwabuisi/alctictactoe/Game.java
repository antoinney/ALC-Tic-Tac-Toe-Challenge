/*
 * Copyright 2017 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.example.anthonynwabuisi.alctictactoe;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;

/**
 * Game show the 3 * 3 grid game
 */
public class Game extends Activity{

    Button[][] gameButtons = new Button[3][3];
    boolean isPlayer1Turn = true;
    int turns,rounds = 0;
    boolean isSinglePlayer;
    TextView player1, player2 , p1Score, p2Score;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.game);

        player1 = (TextView) findViewById(R.id.G1p1);
        player2 = (TextView) findViewById(R.id.G1p2);

        p1Score = (TextView) findViewById(R.id.G1s1);
        p2Score = (TextView) findViewById(R.id.G1s2);


        /*
        instanciate buttons
         */
        gameButtons[0][0] = (Button) findViewById(R.id.btn_00);
        gameButtons[0][1] = (Button) findViewById(R.id.btn_01);
        gameButtons[0][2] = (Button) findViewById(R.id.btn_02);
        gameButtons[1][0] = (Button) findViewById(R.id.btn_10);
        gameButtons[1][1] = (Button) findViewById(R.id.btn_11);
        gameButtons[1][2] = (Button) findViewById(R.id.btn_12);
        gameButtons[2][0] = (Button) findViewById(R.id.btn_20);
        gameButtons[2][1] = (Button) findViewById(R.id.btn_21);
        gameButtons[2][2] = (Button) findViewById(R.id.btn_22);

        //Get isSingle intent
        isSinglePlayer = getIntent().getExtras().getBoolean("isSingle");

        if (!isSinglePlayer){
            player2.setText("Player 2");
        }
    }

    /**
     * Click a random button
     * @param turns is the number of time the systems tries to click an Enabled button
     */
    public void RandomClick(int turns){
        Random random = new Random();
        Button btn = gameButtons[random.nextInt(3)][random.nextInt(3)];
        if (turns < 1){
            return;
        }
        if (btn.isEnabled()){
            setBtnToO(btn);
            return;
        }else {
            turns--;
            RandomClick(turns);
        }
    }

    /**
     * Resets the game
     * @param view refers to the calling view
     */
    public void reset(View view){
        reset();
    }


    /**
     * Handles button game button clicks
     * @param view refers to the calling view
     */
    public void doClick(View view){
        Button btn = (Button) view;
        if (!btn.isEnabled()) return;
        turns++;
        if (!isSinglePlayer){
            if (isPlayer1Turn){
                setBtnToX(btn);
                if (checkForWin()){
                    int score = Integer.parseInt(String.valueOf(p1Score.getText()));
                    score ++;
                    p1Score.setText(String.valueOf(score));
                    rounds++;
                    reset();
                    Toast.makeText(this,"Player 1 wins",Toast.LENGTH_SHORT).show();
                    if (isGameOver()){
                            int sc = Integer.valueOf(String.valueOf(p1Score.getText()));
                            int sc2 = Integer.valueOf(String.valueOf(p2Score.getText()));

                            if (sc2 > sc){
                                isPlayer1Turn = false;
                                showMessage();
                            }else if (sc2 < sc){
                                isPlayer1Turn = true;
                                showMessage();
                            }else {
                                Tie();
                            }
                    }else if(turns == 9 && !isGameOver()){
                        Toast.makeText(this,"No Winner this round",Toast.LENGTH_SHORT).show();
                        reset();
                        rounds++;
                    }
                }else if (turns == 9 && !checkForWin()){
                    if (isGameOver()){
                        gameOver();
                    }else {
                        Toast.makeText(this,"No Winner this round",Toast.LENGTH_SHORT).show();
                        reset();
                        rounds++;
                    }

                }else {
                    isPlayer1Turn = !isPlayer1Turn;
                }
            }else {
                setBtnToO(btn);
                if (checkForWin()){
                    int score = Integer.parseInt(String.valueOf(p2Score.getText()));
                    score ++;
                    p2Score.setText(String.valueOf(score));
                    rounds++;
                    Toast.makeText(this,"Player 2 wins",Toast.LENGTH_SHORT).show();
                    reset();
                    if (isGameOver()){
                        int sc = Integer.valueOf(String.valueOf(p1Score.getText()));
                        int sc2 = Integer.valueOf(String.valueOf(p2Score.getText()));

                        if (sc2 > sc){
                            isPlayer1Turn = false;
                            showMessage();
                        }else if (sc2 < sc){
                            isPlayer1Turn = true;
                            showMessage();
                        }else {
                            Tie();
                        }
                    }else if(turns == 9 && !isGameOver()){
                        Toast.makeText(this,"No Winner this round",Toast.LENGTH_SHORT).show();
                        reset();
                        rounds++;
                    }
                }else if (turns == 9 && !checkForWin()){
                    if (isGameOver()){
                        gameOver();
                    }else {
                        Toast.makeText(this,"No Winner this round",Toast.LENGTH_SHORT).show();
                        reset();
                        rounds++;
                    }

                }else {
                    isPlayer1Turn = !isPlayer1Turn;
                }
            }
        }

        //single player mode
        else {
            setBtnToX(btn);
            if (checkForWin()){
                int score = Integer.parseInt(String.valueOf(p1Score.getText()));
                score ++;
                p1Score.setText(String.valueOf(score));
                rounds++;
                Toast.makeText(this,"You win",Toast.LENGTH_SHORT).show();
                reset();
                if (isGameOver()){
                    int sc = Integer.valueOf(String.valueOf(p1Score.getText()));
                    int sc2 = Integer.valueOf(String.valueOf(p2Score.getText()));

                    if (sc2 > sc){
                        isPlayer1Turn = false;
                        showMessage();
                    }else if (sc2 < sc){
                        isPlayer1Turn = true;
                        showMessage();
                    }else {
                        Tie();
                    }
                }else if(turns == 9 && !isGameOver()){
                    Toast.makeText(this,"No Winner this round",Toast.LENGTH_SHORT).show();
                    reset();
                    rounds++;
                }
            }else if (turns == 9 && !checkForWin()){
                if (isGameOver()){
                    gameOver();
                }else {
                    Toast.makeText(this,"No Winner this round",Toast.LENGTH_SHORT).show();
                    reset();
                    rounds++;
                }

            }else {
                isPlayer1Turn = !isPlayer1Turn;
                RandomClick(9);
                if (checkForWin()){
                    int score = Integer.parseInt(String.valueOf(p2Score.getText()));
                    score ++;
                    p2Score.setText(String.valueOf(score));
                    rounds++;
                    Toast.makeText(this,"Computer Wins",Toast.LENGTH_SHORT).show();
                    reset();
                    if (isGameOver()){
                        int sc = Integer.valueOf(String.valueOf(p1Score.getText()));
                        int sc2 = Integer.valueOf(String.valueOf(p2Score.getText()));

                        if (sc2 > sc){
                            isPlayer1Turn = false;
                            showMessage();
                        }else if (sc2 < sc){
                            isPlayer1Turn = true;
                            showMessage();
                        }else {
                            Tie();
                        }
                    }else if(turns == 9 && !isGameOver()){
                        Toast.makeText(this,"No Winner this round",Toast.LENGTH_SHORT).show();
                        reset();
                        rounds++;
                    }
                }else if (turns == 9 && !checkForWin()){
                    if (isGameOver()){
                        gameOver();
                    }else {
                        Toast.makeText(this,"No Winner this round",Toast.LENGTH_SHORT).show();
                        reset();
                        rounds++;
                    }

                }else {
                    isPlayer1Turn = !isPlayer1Turn;
                }
            }
        }
    }

    /*
    checks if any player wins
     */
    public boolean checkForWin() {
        String[][] btnTexts = new String[3][3];

        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                btnTexts[i][j] = gameButtons[i][j].getText().toString();
            }
        }

        for (int i = 0; i < 3; i++) {
            if (btnTexts[i][0].equals(btnTexts[i][1])
                    && btnTexts[i][0].equals(btnTexts[i][2])
                    && !btnTexts[i][0].equals("")) {
                return true;
            }
        }

        for (int i = 0; i < 3; i++) {
            if (btnTexts[0][i].equals(btnTexts[1][i])
                    && btnTexts[0][i].equals(btnTexts[2][i])
                    && !btnTexts[0][i].equals("")) {
                return true;
            }
        }

        if (btnTexts[0][0].equals(btnTexts[1][1])
                && btnTexts[0][0].equals(btnTexts[2][2])
                && !btnTexts[0][0].equals("")) {
            return true;
        }

        if (btnTexts[0][2].equals(btnTexts[1][1])
                && btnTexts[0][2].equals(btnTexts[2][0])
                && !btnTexts[0][2].equals("")) {
            return true;
        }

        return false;
    }

    /*
    sends the user to the game over view
     */
    public void gameOver(){
            Intent intent = new Intent(Game.this,Message.class);
            intent.putExtra("message","GAME OVER!");
            startActivity(intent);
            finish();
    }

    /*
    sends the user to the Tie view
     */
    public void Tie(){
        Intent intent = new Intent(Game.this,Message.class);
        intent.putExtra("message","GAME Ended with a Tie!");
        startActivity(intent);
        finish();
    }


    /*
    shows a win message
     */
    public void showMessage(){
            Intent intent;
            if (isSinglePlayer){
                if (isPlayer1Turn){
                    intent = new Intent(Game.this,Message.class);
                    intent.putExtra("message","You Win!");
                }else {
                    intent = new Intent(Game.this,Message.class);
                    intent.putExtra("message","Computer WINS!");
                }
                startActivity(intent);
                finish();
            }else {
                if (isPlayer1Turn){
                    intent = new Intent(Game.this,Message.class);
                    intent.putExtra("message","Player 1 WINS!");
                }else {
                    intent = new Intent(Game.this,Message.class);
                    intent.putExtra("message","Player 2 WINS!");
                }
                startActivity(intent);
                finish();
            }

    }

    /**
     * set button to "X" and disables it
     * @param button
     */
    public void setBtnToX(Button button){
        button.setText("X");
        button.setEnabled(false);
    }

    /**
     * set button to "O" and disables it
     * @param button
     */
    public void setBtnToO(Button button){
        button.setText("O");
        button.setEnabled(false);
    }

    /*
    checks if game is over
     */
    public boolean isGameOver(){
        if (rounds > 3) {
            return true;
        }
        else{
            return false;
        }
    }

    /*
    resets the game
     */
    public void reset(){
        for (int x = 0; x < 3; x++){
            for (int y = 0 ; y < 3; y++){
                gameButtons[x][y].setEnabled(true);
                gameButtons[x][y].setText("");
            }
        }
        turns = 0;
    }

}
